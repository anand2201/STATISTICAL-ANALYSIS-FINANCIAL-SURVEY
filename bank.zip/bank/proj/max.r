NEFT_data = LOAD '/usr/local/hadoop/sw20/neft/NEFT.csv' USING PigStorage(',') as (Sr_no:int, Month:chararray, Bank_name:chararray, Debit_trans:int, Debit_amt:int, Credit_trans:int,Credit_amt:int);
Debit_max = foreach NEFT_data  Generate
   (Bank_name,Debit_trans), MAX(Debit_trans);

Dump Debit_max;

