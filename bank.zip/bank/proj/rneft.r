Sys.setenv(HADOOP_PREFIX="/usr/local/hadoop")
Sys.setenv(HADOOP_CMD="/usr/local/hadoop/bin/hadoop")
Sys.setenv(HADOOP_STREAMING="/usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-2.7.3.jar")
library(rhdfs)
library(rmr2)
hdfs.init()
hdfs.ls('/')

f=hdfs.read.text.file("/usr/local/hadoop/sw20/project2/grpans1/part-r-00000")

f