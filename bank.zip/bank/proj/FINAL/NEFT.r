Sys.setenv(HADOOP_PREFIX="/usr/local/hadoop")
Sys.setenv(HADOOP_CMD="/usr/local/hadoop/bin/hadoop")
Sys.setenv(HADOOP_STREAMING="/usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-2.7.3.jar")
library(rhdfs)
library(rmr2)
hdfs.init()
hdfs.ls('/')
#NEFT
A=hdfs.read.text.file('/usr/local/hadoop/sw20/project/neftout/part-m-00000')
write.csv(f, "data.csv", row.names=FALSE)
NEFT=read.csv("/home/sw20/data.csv",header=FALSE)
X=NEFT$V2
Y=NEFT$V6
Y=Y/1000000
E=barplot(Y,space = 0.8,names.arg = X,xlab = "MONTH",ylab = "TRANSACTION(in millions)",ylim = c(0,35),col = "blue",
        main = "NEFT TRANSACTION  ",cex.names=0.8,border = "red", las=2)
Sl=round(Y,digits = 2)
text(x = E, y = Sl, label = Sl, pos = 3, cex = 0.8, col = "red")


#MOB
B=hdfs.read.text.file('/usr/local/hadoop/group1test/mobileanswer/answer/part-m-00000')
write.csv(B, "data1.csv", row.names=FALSE)
MOB=read.csv("/home/sw20/data1.csv",header=FALSE)
S=MOB$V2
M=MOB$V4
M=M/1000000
G=barplot(M,space = 0.8,names.arg = S,xlab = "MONTH",ylab = "TRANSACTION(in millions)",ylim = c(0,25),col = "blue",
        main = "MOBILE TRANSACTION ",cex.names=0.8,border = "red", las=2)
U=round(M,digits = 2)
text(x = G, y = U, label = U, pos = 3, cex = 0.8, col = "red")


#ECS
C=hdfs.read.text.file('/francis/project/ecs.csv/000000_0')
write.csv(C, "data2.csv", row.names=FALSE)
ECS=read.csv("/home/sw20/data2.csv",header=FALSE)
M=ECS$V1
N=ECS$V2
N=N/1000000
Fl=barplot(N,space = 0.8,names.arg = M,xlab ="MONTH",ylab = "TRANSACTION(in millions)",col = "blue",ylim = c(0,1),
        main = " ECS TRANSACTION  ",cex.names=0.8,border = "red", las=2)
X=round(N,digits = 2)
text(x = Fl, y = X, label = X, pos = 3, cex = 0.8, col = "red")




#RTGS
D=hdfs.read.text.file('/francis/project/hive.csv/000000_0')
write.csv(D, "data3.csv", row.names=FALSE)
RTGS=read.csv("/home/sw20/data3.csv",header=FALSE)
O=RTGS$V2
P=RTGS$V6
P=P/1000000
Gl=barplot(P,space = 0.8,names.arg = O,xlab = "MONTH",ylab = "TRANSACTION(in millions)",col = "blue",ylim = c(0,3.5),
        main = "RTGS TRANSACTION  ",cex.names=0.8,border = "red", las=2)
Y=round(P,digits = 2)
text(x = Gl, y = Y, label = Y, pos = 3, cex = 0.8, col = "red")


