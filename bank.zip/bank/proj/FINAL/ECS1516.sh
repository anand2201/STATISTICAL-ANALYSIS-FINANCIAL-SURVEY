CREATE TABLE IF NOT EXISTS ECSyr1516 (Sr_no int, Month varchar(10),Place varchar(10), Bank_name varchar(10), Credit_vol int, Debit_vol int, Tot_vol int)row format delimited fields terminated by ',' lines terminated by '\n';

LOAD DATA LOCAL INPATH '/home/sw20/project/bank/proj/FINAL/ECS1516.csv' OVERWRITE INTO TABLE ECSyr1516;

INSERT OVERWRITE DIRECTORY '/usr/local/hadoop/sw20/projectyear/ECS1516'  ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' select Month,max(Tot_vol) from ECSyr1516 group by Month ;

