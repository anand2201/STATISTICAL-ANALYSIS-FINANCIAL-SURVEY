CREATE TABLE IF NOT EXISTS RTGSyr1516 (Sr_no int, Month varchar(10), Bank_name varchar(10), Debit_trans int, Credit_trans int, trans_tot int)row format delimited fields terminated by ',' lines terminated by '\n';

LOAD DATA LOCAL INPATH '/home/sw20/project/bank/proj/FINAL/RTGS1516.csv' OVERWRITE INTO TABLE RTGSyr1516;

INSERT OVERWRITE DIRECTORY '/usr/local/hadoop/sw20/projectyear/RTGSyr1516'  ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' select Month,max(trans_tot) from RTGSyr1516 group by Month ;

