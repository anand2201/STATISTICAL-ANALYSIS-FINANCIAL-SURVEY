hive -e "CREATE TABLE IF NOT EXISTS NEFT (Sr_no int, Month varchar(10), Bank_name varchar(10), Debit_trans int, Credit_trans int, trans_tot int, Debit_amt float,Credit_amt float, amt_tot float)row format delimited fields terminated by ',' lines terminated by '\n';"

LOAD DATA LOCAL INPATH '/home/sw20/project/bank/proj/FINAL/NEFTfinal.csv' OVERWRITE INTO TABLE NEFT;

INSERT OVERWRITE LOCAL DIRECTORY '/home/sw20/Documents/NEFT'  ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' select Bank_name,avg(trans_tot) from NEFT group by Bank_name ;

