CREATE TABLE IF NOT EXISTS MObileyr1516 (Sr_no int, Month varchar(10), Bank_name varchar(10), Volume_trans int, Value_trans int)row format delimited fields terminated by ',' lines terminated by '\n';

LOAD DATA LOCAL INPATH '/home/sw20/project/bank/proj/FINAL/Mobile1516.csv' OVERWRITE INTO TABLE Mobileyr1516;

INSERT OVERWRITE DIRECTORY '/usr/local/hadoop/sw20/projectyear/Mobileyr1516'  ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' select Month,max(Volume_trans) from Mobileyr1516 group by Month ;

