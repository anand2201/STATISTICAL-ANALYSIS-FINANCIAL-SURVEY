Sys.setenv(HADOOP_PREFIX="/usr/local/hadoop")
Sys.setenv(HADOOP_CMD="/usr/local/hadoop/bin/hadoop")
Sys.setenv(HADOOP_STREAMING="/usr/local/hadoop/share/hadoop/tools/lib/hadoop-streaming-2.7.3.jar")
library(rhdfs)
library(rmr2)
hdfs.init()
hdfs.ls('/')
#neg
A=hdfs.read.text.file('/francis/project/twitter/negative/000000_0')
write.csv(A, "neg.csv", row.names=FALSE)
NEG=read.csv("/home/sw20/neg.csv",header=FALSE)

#pos
B=hdfs.read.text.file('/francis/project/twitter/positive/000000_0')
write.csv(B, "pos.csv", row.names=FALSE)
POS=read.csv("/home/sw20/pos.csv",header=FALSE)

barplot(c(38,33),space = 0.8,ylab = "count",main =("Twitter Analysis"),names.arg = c("negative" ,"positive"),ylim = c(0,40),col =c("red","green"))


