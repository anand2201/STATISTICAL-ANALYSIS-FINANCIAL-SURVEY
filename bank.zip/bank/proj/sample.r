sample =read.csv(file.choose(),header = FALSE)
d=data.frame(sample)
head(d)

sampl =read.csv(file.choose(),header = FALSE)
e=data.frame(sampl)
head(e)

library(ggplot2)
ggplot(means.long,aes(x=variable,y=value,fill=factor(gender)))+
  geom_bar(stat="identity",position="dodge")+
  scale_fill_discrete(name="Gender",
                      breaks=c(1, 2),
                      labels=c("Male", "Female"))+
  xlab("Beverage")+ylab("Mean Percentage")
c=