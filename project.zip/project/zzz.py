from Tkinter import *

def sel():
    x = canvas.create_image(500,300, image=tk_img)
    x.pack()




root = Tk()              
tk_img = ImageTk.PhotoImage(file='/home/sw15/Documents/project/R/2002Rplot.jpeg')       
R1 = Radiobutton(root, text="2002", variable=var, value=1,
                  command=sel)
R1.pack( anchor = W )

R2 = Radiobutton(root, text="2003", variable=var, value=2,
                  command=sel)
R2.pack( anchor = W )

R3 = Radiobutton(root, text="2004", variable=var, value=3,
                  command=sel)
R3.pack( anchor = W)

R4 = Radiobutton(root, text="2005", variable=var, value=3,
                  command=sel)
R4.pack( anchor = W)

R5 = Radiobutton(root, text="2006", variable=var, value=3,
                  command=sel)
R5.pack( anchor = W)

R6 = Radiobutton(root, text="2007", variable=var, value=3,
                  command=sel)
R6.pack( anchor = W)

R7 = Radiobutton(root, text="2008", variable=var, value=3,
                  command=sel)
R7.pack( anchor = W)

R8 = Radiobutton(root, text="2009", variable=var, value=3,
                  command=sel)
R8.pack( anchor = W)

R9 = Radiobutton(root, text="2010", variable=var, value=3,
                  command=sel)
R9.pack( anchor = W)

R10 = Radiobutton(root, text="2011", variable=var, value=3,
                  command=sel)
R10.pack( anchor = W)

R11 = Radiobutton(root, text="2012", variable=var, value=3,
                  command=sel)
R11.pack( anchor = W)

R12 = Radiobutton(root, text="2013", variable=var, value=3,
                  command=sel)
R12.pack( anchor = W)

R13 = Radiobutton(root, text="2014", variable=var, value=3,
                  command=sel)
R13.pack( anchor = W)

R14 = Radiobutton(root, text="2015", variable=var, value=3,
                  command=sel)
R14.pack( anchor = W)

R15 = Radiobutton(root, text="2016", variable=var, value=3,
                  command=sel)
R15.pack( anchor = W)


label = Label(root)
label.pack()
root.mainloop()
