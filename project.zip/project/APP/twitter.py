import Tkinter as tk
import ImageTk
from Tkinter import *



def show_image1():
    x = canvas.create_image(500,300, image=tk_img1)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button1.configure(text = 'FIND')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button1.configure(text = 'FIND')        
        yield

root = tk.Tk()
canvas = tk.Canvas(root, width=1000, height=600)
canvas.grid(row=5, column=8)


label1 = Label( root, text=" TWITTER SENTIMENT ANALYSIS on PAYTM") 
label1.grid(row =0,column = 0,sticky=tk.NW)






tk_img1 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/twitter plot.jpeg')


button1 = tk.Button(
    root, text="FIND", command=show_image1().next, anchor='n',
    width=10, activebackground="#33B5E5")


button1.grid(row=3, column=0,sticky=tk.NW,)



root.mainloop()

