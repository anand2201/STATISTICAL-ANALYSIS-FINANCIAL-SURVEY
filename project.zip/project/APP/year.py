import Tkinter as tk
import ImageTk
from Tkinter import *





def show_image1():
    x = canvas.create_image(500,300, image=tk_img1)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button1.configure(text = 'NEFT')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button1.configure(text = 'NEFT')        
        yield
def show_image2():
    x = canvas.create_image(500,300, image=tk_img2)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button2.configure(text = 'NEFT')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button2.configure(text = 'NEFT')        
        yield

def show_image3():
    x = canvas.create_image(500,300, image=tk_img3)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button3.configure(text = 'RGTS')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button3.configure(text = 'RGTS')        
        yield
def show_image4():
    x = canvas.create_image(500,300, image=tk_img4)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button4.configure(text = 'IMPS')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button4.configure(text = 'IMPS')        
        yield
def show_image5():
    x = canvas.create_image(500,300, image=tk_img5)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button5.configure(text = 'ECS')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button5.configure(text = 'ECS')        
        yield
def show_image6():
    x = canvas.create_image(500,300, image=tk_img6)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button6.configure(text = 'ECS')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button6.configure(text = 'ECS')        
        yield
def show_image7():
    x = canvas.create_image(500,300, image=tk_img7)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button7.configure(text = 'Mobile')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button7.configure(text = 'Mobile')        
        yield
def show_image8():
    x = canvas.create_image(500,300, image=tk_img8)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button8.configure(text = 'NEFT')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button8.configure(text = 'NEFT')        
        yield        
def show_image9():
    x = canvas.create_image(500,300, image=tk_img9)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button9.configure(text = 'RTGS')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button9.configure(text = 'RTGS')        
        yield  
def show_image10():
    x = canvas.create_image(500,300, image=tk_img10)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button10.configure(text = 'Mobile')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button10.configure(text = 'MObile')        
        yield  
def show_image11():
    x = canvas.create_image(500,300, image=tk_img11)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button11.configure(text = 'RTGS')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button11.configure(text = 'RTGS')        
        yield  


        

root = tk.Tk()
canvas = tk.Canvas(root, width=1000, height=600)
canvas.grid(row=5, column=8)


label1 = Label( root, text=" YearWise Transaction Analysis") 
label1.grid(row =0,column = 0,sticky=tk.NW)

#label2 = Label( root, text=" Top BankWise Transaction Analysis") 
#label2.grid(row =0,column = 7,sticky=tk.NW)




tk_img1 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/NEFT.jpg')
tk_img2 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/neft.jpeg')
tk_img3 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/rtgs.jpeg')
tk_img4 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/yearmob.jpeg')
tk_img5 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/yearecs.jpeg')
tk_img6 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/ECSplot.jpeg')
tk_img7 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/mobileplot.jpeg')
tk_img8 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/NEFTplot.jpeg')
tk_img9 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/RTGS.jpeg')
tk_img10 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/IMPS.jpg')
tk_img11 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rgraphs/RTGS.jpg')






#button1 = tk.Button(
  #  root, text="NEFT", command=show_image1().next, anchor='n',
   # width=10, activebackground="#33B5E5")


#button1.grid(row=5, column=7,sticky=tk.NW,)

button2 = tk.Button(
    root, text="NEFT", command=show_image2().next, anchor='n',
    width=10, activebackground="#33B5E5")


button2.grid(row=2, column=0,sticky=tk.NW,)

button3 = tk.Button(
    root, text="RTGS", command=show_image3().next, anchor='n',
    width=10, activebackground="#33B5E5")


button3.grid(row=3, column=0,sticky=tk.NW,)

button4 = tk.Button(
    root, text="Mobile", command=show_image4().next, anchor='n',
    width=10, activebackground="#33B5E5")


button4.grid(row=4, column=0,sticky=tk.NW,)

button5 = tk.Button(
    root, text="ECS", command=show_image5().next, anchor='n',
    width=10, activebackground="#33B5E5")


button5.grid(row=5, column=0,sticky=tk.NW,)

#button6 = tk.Button(
    #root, text="ECS", command=show_image6().next, anchor='n',
    #width=10, activebackground="#33B5E5")


#button6.grid(row=5, column=0,sticky=tk.NW,)

#button7 = tk.Button(
    #root, text="Mobile", command=show_image7().next, anchor='n',
    #width=10, activebackground="#33B5E5")


#button7.grid(row=6, column=0,sticky=tk.NW,)


#button8 = tk.Button(
    #root, text="NEFT", command=show_image8().next, anchor='n',
    #width=10, activebackground="#33B5E5")


#button8.grid(row=7, column=0,sticky=tk.NW,)

#button9 = tk.Button(
    #root, text="RTGS", command=show_image9().next, anchor='n',
    #width=10, activebackground="#33B5E5")


#button9.grid(row=8, column=0,sticky=tk.NW,)

#button10 = tk.Button(
    #root, text="Mobile", command=show_image10().next, anchor='n',
    #width=10, activebackground="#33B5E5")


#button10.grid(row=3, column=7,sticky=tk.NW,)


#button11 = tk.Button(
    #root, text="RTGS", command=show_image11().next, anchor='n',
    #width=10, activebackground="#33B5E5")


#button11.grid(row=4, column=7,sticky=tk.NW,)




root.mainloop()
