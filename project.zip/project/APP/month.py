import Tkinter as tk
import ImageTk
from Tkinter import *



def show_image1():
    x = canvas.create_image(500,300, image=tk_img1)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button1.configure(text = 'ECS')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button1.configure(text = 'ECS')        
        yield


def show_image2():
    x = canvas.create_image(500,300, image=tk_img2)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button2.configure(text = 'NEFT')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button2.configure(text = 'NEFT')        
        yield

def show_image3():
    x = canvas.create_image(500,300, image=tk_img3)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button3.configure(text = 'RGTS')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button3.configure(text = 'RGTS')        
        yield
def show_image4():
    x = canvas.create_image(500,300, image=tk_img4)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button4.configure(text = 'Mobile')
        yield
              
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button4.configure(text = 'Mobile')        
        yield

        

root = tk.Tk()
canvas = tk.Canvas(root, width=1000, height=600)
canvas.grid(row=5, column=8)


label1 = Label( root, text=" MonthWise Transaction Analysis") 
label1.grid(row =0,column = 0,sticky=tk.NW)






tk_img1 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/ecs.jpeg')
tk_img2 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/neft.jpeg')
tk_img3 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/rtgs.jpeg')
tk_img4 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/mob.jpeg')








button1 = tk.Button(
    root, text="ECS", command=show_image1().next, anchor='n',
    width=10, activebackground="#33B5E5")


button1.grid(row=2, column=0,sticky=tk.NW,)

button2 = tk.Button(
    root, text="NEFT", command=show_image2().next, anchor='n',
    width=10, activebackground="#33B5E5")


button2.grid(row=3, column=0,sticky=tk.NW,)

button3 = tk.Button(
    root, text="RTGS", command=show_image3().next, anchor='n',
    width=10, activebackground="#33B5E5")


button3.grid(row=4, column=0,sticky=tk.NW,)

button4 = tk.Button(
    root, text="Mobile", command=show_image4().next, anchor='n',
    width=10, activebackground="#33B5E5")


button4.grid(row=5, column=0,sticky=tk.NW,)




root.mainloop()
