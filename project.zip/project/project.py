import Tkinter as tk
from Tkinter import *
import ImageTk
root = Tk()
frame = Frame(root,width=1000,height =600)
frame.grid()


def show_image1():
    x = canvas.create_image(500,300, image=tk_img1)
    while True:
        
        canvas.itemconfigure(x, state=tk.NORMAL)
        button1.configure(text = '2002')
        yield
        canvas.itemconfigure(x, state=tk.HIDDEN)
        button1.configure(text = '2002')        
        yield
canvas = tk.Canvas(root, width=100, height=100)
canvas.grid(row=0, column=0)

tk_img1 = ImageTk.PhotoImage(file='/home/sw15/Documents/project/Rplot01.jpeg')
button1 = tk.Button(
    root, text="2002", command=show_image1().next, anchor='n',
    width=5, activebackground="#33B5E5")
button1.grid(row=0, column=0,sticky=tk.NW,columnspan=2)

#var = StringVar()
#label = Label( root, textvariable=var, relief=RAISED ,width =10,height =2)

#label.pack()
lab1 = Label(root,height=2,width=50,text="Statistical Analysis & Financial Survey")
 
#Questions
lab2 =Label(root,height=2,width=100,text ="Which bank has the maximum number of transactions NEFT/RTGS in 2016?" )
lab3 =Label(root,height=2,width=100,text ="Which bank has the maximum number of transactions NEFT/RTGS in 2016?" )
lab4 =Label(root,height=2,width=100,text ="Which bank has the maximum number of transactions NEFT/RTGS in 2016?" )
lab5 =Label(root,height=2,width=100,text ="Which bank has the maximum number of transactions NEFT/RTGS in 2016?" )
lab6 =Label(root,height=2,width=100,text ="Which bank has the maximum number of transactions NEFT/RTGS in 2016?" )


lab1.grid(row=0, column=0,sticky=tk.N)
lab2.grid(row =10 ,column =0)
lab3.grid(row =9,column=0)
root.mainloop()
