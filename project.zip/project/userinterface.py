
import Tkinter
top = Tkinter.Tk()
# Code to add widgets will go here...



filename = PhotoImage(file = "Telecom-Industry-India.jpg")
image = canvas.create_image(50, 50, anchor=NE, image=filename)
image.pack()
top.mainloop()

