q=read.csv(file.choose())
s=q$Service.Area
r02=q$March.02
barplot(r02,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2002 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r03=q$March.03
barplot(r03,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2003 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r04=q$March.04
barplot(r04,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2004 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r05=q$March.05
barplot(r05,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2005 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r06=q$March.06
barplot(r06,names.arg = s,xlab = "Service.Area",cex.names=0.6,ylab = "Teledensity",col = "blue",
        main = "2006 Statewise Teledensity  ",border = "red", las=2)

r07=q$March.07
barplot(r07,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2007 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r08=q$March.08
barplot(r08,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2008 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r09=q$March.09
barplot(r09,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2009 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r10=q$March.10
barplot(r10,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2010 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r11=q$March.11
barplot(r11,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2011 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r12=q$March.12
barplot(r12,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2012 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r13=q$March.13
barplot(r13,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2013 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r14=q$March.14
barplot(r14,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2014 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r15=q$March.15
barplot(r15,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2015 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)

r16=q$March.16
barplot(r16,names.arg = s,xlab = "Service.Area",ylab = "Teledensity",col = "blue",
        main = "2016 Statewise Teledensity  ",cex.names=0.6,border = "red", las=2)


dev.off()